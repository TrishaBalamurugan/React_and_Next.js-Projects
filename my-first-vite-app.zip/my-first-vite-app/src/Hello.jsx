export default function App() {
  return <h1>Hello React is working!</h1>;
}